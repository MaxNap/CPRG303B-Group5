import { ExpoRouter } from 'expo-router';

export default ExpoRouter;